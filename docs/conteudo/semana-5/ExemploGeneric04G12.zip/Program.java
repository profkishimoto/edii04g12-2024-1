
public class Program {

	public static void main(String[] args) {
		Node n = new Node("teste");
		System.out.println("n: " + n);
		
		NodeGeneric<String> ng = new NodeGeneric<String>("classe genérica");
		System.out.println("ng: " + ng);
		
		NodeGeneric<Integer> nodeInt = new NodeGeneric<Integer>(99);
		System.out.println("nodeInt: " + nodeInt);
		
		NodeGeneric<MyData> nodeMyData = new NodeGeneric<MyData>(new MyData(1000, "abc"));
		System.out.println("nodeMyData: " + nodeMyData);

		MyData temp = nodeMyData.getData();
		temp.setId(999);
		temp.setStr("Hello, World!");
		System.out.println("nodeMyData: " + nodeMyData);
		
		// Method chaining.
		nodeMyData
			.getData()
			.setId(-10)
			.setStr("xyz");
		System.out.println("nodeMyData: " + nodeMyData);
		
	}

}
