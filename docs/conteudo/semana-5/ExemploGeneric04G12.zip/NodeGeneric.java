
public class NodeGeneric<T> {
	
	private T data;
	private NodeGeneric<T> parent;
	private NodeGeneric<T> left;
	private NodeGeneric<T> right;
	
	public NodeGeneric() {
		this(null);
	}
	
	public NodeGeneric(T data) {
		this.data = data;
		parent = null;
		left = null;
		right = null;
	}
	
	public T getData() {
		return data;
	}

	@Override
	public String toString() {
		return data.toString();
	}
	
}
