package ed2;

public class PessoaFisica extends Pessoa {
	
	private String cpf;
	
	public PessoaFisica() {
		super();
		cpf = "N/A";
		System.out.println("ctor --> PessoaFisica()");
	}
	
	public PessoaFisica(String nome, String telefone, String email, String cpf) {
		super(nome, telefone, email);
		this.cpf = cpf;
		System.out.println("ctor --> PessoaFisica(" + nome + ", " + telefone + ", " + email + ", " + cpf + ")");
	}
	
	public String getCpf() {
		return cpf;
	}
	
	@Override
	public String toString() {
		return "Nome: " + nome + ", telefone: " + getTelefone() + ", CPF: " + cpf;
	}

}
