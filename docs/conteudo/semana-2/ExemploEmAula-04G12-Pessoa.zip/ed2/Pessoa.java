package ed2;

public class Pessoa {

	protected String nome;
	private String telefone;
	private String email;
	
	public Pessoa() {
		this("N/A", "N/A", "N/A");
		System.out.println("ctor --> Pessoa()");
	}
	
	public Pessoa(String nome, String telefone, String email) {
		this.nome = nome;
		this.telefone = telefone;
		this.email = email;
		System.out.println("ctor --> Pessoa(" + nome + ", " + telefone + ", " + email + ")");
	}
	
	public String getTelefone() {
		return telefone;
	}
	
	@Override
	public String toString() {
		return super.toString()
		+ "; " + nome + "; " + telefone + "; " + email;
	}
}
