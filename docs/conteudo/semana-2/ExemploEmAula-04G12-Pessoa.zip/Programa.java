import ed2.Pessoa;
import ed2.PessoaFisica;

public class Programa {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa();
		System.out.println("p1: " + p1.toString());

		Pessoa p2 = new Pessoa("Alguem", "(11) ...", "email@email.com.br");
		System.out.println("p2: " + p2);
		
		PessoaFisica pf1 = new PessoaFisica();
		System.out.println("pf1: " + pf1);
		
		PessoaFisica pf2 = new PessoaFisica("Pf", "(21) ...", "pf@pf", "123.456.789-00");
		System.out.println("pf2: " + pf2);
		
		Pessoa pessoas[] = new Pessoa[4];
		pessoas[0] = new Pessoa();
		pessoas[1] = new Pessoa("abc", "(41) ...", "abc@abc.com");
		pessoas[2] = new PessoaFisica();
		pessoas[3] = new PessoaFisica("xyz", "(11)...", "xyz@email", "123.456...");
		
		// for each
		for (Pessoa p : pessoas) {
			System.out.println(p);
			if (p instanceof PessoaFisica) {
				System.out.println("CPF ----> " + ((PessoaFisica)p).getCpf());
			}
		}
		
		
		
		
	}

}
