import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
	
	public static String[] load(String filename) throws FileNotFoundException, IOException {
		InputStream is = new FileInputStream(filename);
		InputStreamReader isr = new InputStreamReader(is, "UTF-8");
		BufferedReader br = new BufferedReader(isr);
		
		StringBuilder sb = new StringBuilder();
		while (true) {
			String line = br.readLine();
			if (line == null) {
				break;
			}
			sb.append(line).append('\n');
		}
		
		is.close();
		
		return sb.toString().split("#|\\r?\\n|\\r");
	}

	public static void main(String[] args) {
		final String DATA_FILENAME = "imdb.txt";
		
		Scanner scanner = new Scanner(System.in);
		String input = "";
		int option = 0;
		LinkedList<Movie> movieList = new LinkedList<Movie>();
		
		while (option != 3) {
			System.out.println("1. Carregar dados");
			System.out.println("2. Exibir dados");
			System.out.println("3. Sair");
			System.out.print("Opção: ");
			input = scanner.nextLine();
			
			try {
				option = Integer.parseInt(input);
			} catch (NumberFormatException e) {
				option = 0;
			}
			
			switch (option) {
				case 1 -> {
					try {
						movieList.clear();
						var data = load(DATA_FILENAME);
						for (int i = 0; i < data.length; i += 3) {
							movieList.add(new Movie(data[i], Integer.parseInt(data[i + 1]), Float.parseFloat(data[i + 2])));
						}
						System.out.println("Dados carregados do arquivo '" + DATA_FILENAME + "'.");
					} catch (Exception e) {
						System.out.println("Não foi possível ler conteúdo do arquivo '" + DATA_FILENAME + "'.");
					}
				}
				
				case 2 -> {
					int i = 1;
					for (var movie : movieList) {
						System.out.println("#" + i + ": " + movie);
						++i;
					}
					System.out.println();
				}
				
				case 3 -> {
					// Faz nada.
				}
				
				default -> {
					System.out.println("*** Opção inválida!");
				}
			}
		}
		
		scanner.close();
		System.out.println("Fim.");
	}
	
}
