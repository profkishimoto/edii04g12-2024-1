
public class Movie {

	private String title;
	private int year;
	private float score;
	
	public Movie() {
		this("N/A", 0, 0.0f);
	}
	
	public Movie(String title, int year, float score) {
		this.title = title;
		this.year = year;
		this.score = score;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public int getYear() {
		return year;
	}
	
	public void setYear(int year) {
		this.year = year;
	}
	
	public float getScore() {
		return score;
	}
	
	public void setScore(float score) {
		this.score = score;
	}
	
	@Override
	public String toString() {
		return title + " (" + year + ") " + score;
	}
	
}
