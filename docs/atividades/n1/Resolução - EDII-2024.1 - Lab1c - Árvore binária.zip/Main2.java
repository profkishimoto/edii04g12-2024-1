//
// Árvore Binária - Exemplo de implementação em Java
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

//
// Árvore criada no código abaixo:
//
//        A
//      /   \
//     B     C
//    /     / \
//   D     E   F
//

import ed2.BTNode;
import ed2.BinaryTree;

public class Main2 {

	public static void main(String[] args) {
		BTNode a = new BTNode("A");
		BTNode b = new BTNode("B");
		BTNode c = new BTNode("C");
		BTNode d = new BTNode("D");
		BTNode e = new BTNode("E");
		BTNode f = new BTNode("F");
		a.setLeft(b);
		a.setRight(c);
		b.setLeft(d);
		c.setLeft(e);
		c.setRight(f);
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		
		System.out.println("--------------------");
		BinaryTree tree = new BinaryTree(a); 
		System.out.println(tree);
		System.out.println("Pré-ordem: " + tree.preOrderTraversal());
		System.out.println(" Em ordem: " + tree.inOrderTraversal());
		System.out.println("Pós-ordem: " + tree.postOrderTraversal());
		System.out.println("Por nível: " + tree.levelOrderTraversal());
	}

}
