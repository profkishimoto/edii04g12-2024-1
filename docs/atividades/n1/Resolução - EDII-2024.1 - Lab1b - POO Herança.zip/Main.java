import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		LinkedList<VeiculoTerrestre> veiculos = new LinkedList<VeiculoTerrestre>();
		veiculos.add(new CarroDePasseio(1990, "Azul", 5));
		veiculos.add(new CarroDePasseio(2004, "Cinza", 4));
		veiculos.add(new Caminhao(1999, "Verde", 4));
		veiculos.add(new CarroDePasseio(2010, "Preta", 5));
		veiculos.add(new CarroDePasseio(2009, "Preta", 7));
		veiculos.add(new Caminhao(2011, "Verde", 4));
		veiculos.add(new Caminhao(2000, "Azul", 4));
		veiculos.add(new Caminhao(2005, "Preto", 3));
		
		for (var veiculo : veiculos) {
			if (veiculo instanceof CarroDePasseio) {
				CarroDePasseio temp = (CarroDePasseio)veiculo;
				if (temp.getTotalDePassageiros() >= 5 && temp.getAno() < 2010) {
					System.out.println(temp);
				}
			}
		}
		
		int n = 0;
		for (var veiculo : veiculos) {
			if (veiculo instanceof Caminhao) {
				Caminhao temp = (Caminhao)veiculo;
				if (temp.getCor().equalsIgnoreCase("verde") && temp.getTotalDeEixos() == 4) {
					System.out.println(temp);
					++n;
				}
			}
		}
		System.out.println("Total de caminhão verde com 4 eixos: " + n);
	}

}
