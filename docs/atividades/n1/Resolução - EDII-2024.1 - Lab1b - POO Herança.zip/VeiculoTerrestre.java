
public class VeiculoTerrestre {
	
	private int ano;
	private String cor;
	
	public VeiculoTerrestre(int ano, String cor) {
		this.ano = ano;
		this.cor = cor;
	}
	
	public int getAno() {
		return ano;
	}
	
	public void setAno(int ano) {
		this.ano = ano;
	}
	
	public String getCor() {
		return cor;
	}
	
	public void setCor(String cor) {
		this.cor = cor;
	}
	
	@Override
	public String toString() {
		return "Veículo Terrestre: ano = " + ano + ", cor = " + cor;
	}

}
